package events_utils

type GeneralEventSource struct {}

func (g GeneralEventSource) Filename() string {
	return ""
}
