package compiler

type CompiledProgram struct {}