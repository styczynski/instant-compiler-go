package compiler_pipeline

type CompilerPipelineInterface interface {
	Run()
}
