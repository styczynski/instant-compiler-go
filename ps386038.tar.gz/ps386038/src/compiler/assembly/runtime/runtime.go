package runtime

// func GetRuntimeSymbolsDependencies(program *ir.IRProgram) {
// 	for _, fn := range program.Statements {
// 		for _, stmt := range program.Statements {
// 			used := cfg.GetAllUsagesVariables(stmt, map[generic_ast.TraversableNode]struct{}{})
// 			for _, varName := range used.Names() {
// 				if varName
// 			}
// 		}
// 	}
// }
