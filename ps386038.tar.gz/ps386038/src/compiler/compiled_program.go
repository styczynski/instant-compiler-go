package compiler

type CompiledProgram interface {
	ProgramToText() string
}
